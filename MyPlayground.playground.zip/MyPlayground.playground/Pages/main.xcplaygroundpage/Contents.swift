

// write your code here

func helloWorld(){
print("Hello, world!")
}

helloWorld()

// write your code here

func printConstent(){
    let pi = 3.14
    print(pi)
}

printConstent()

// write your code here

func greetingMessage(name:String){
print("Welcome "\(name))
}

greetingMessage(name: "ali")
greetingMessage(name: "javad")
greetingMessage(name: "asif")

// write your code here
let name= "ali"
var vname:String
greetingMessage(name: name)
vname="ali"
greetingMessage(name: vname)

vname= "johari"
greetingMessage(name: vname)

// write your code here


func myfuntion(){
    
    var firstname="Firstname"
    print(firstname)
    firstname="new name"
    print(firstname)
    
}
myfuntion()
myfuntion()
myfuntion()
